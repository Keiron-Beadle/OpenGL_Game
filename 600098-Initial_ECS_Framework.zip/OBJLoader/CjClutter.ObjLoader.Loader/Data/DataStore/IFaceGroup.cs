using ObjLoader.Loader.Data.Elements;

namespace ObjLoader.Loader.Data.DataStore
{
    public interface IFaceGroup
    {
        void AddFace(Face face);
    }
}