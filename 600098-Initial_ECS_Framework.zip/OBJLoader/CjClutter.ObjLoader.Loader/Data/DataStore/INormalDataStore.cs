using ObjLoader.Loader.Data.VertexData;

namespace ObjLoader.Loader.Data.DataStore
{
    public interface INormalDataStore
    {
        void AddNormal(Normal normal);
    }
}