namespace ObjLoader.Loader.TypeParsers.Interfaces
{
    public interface IVertexParser : ITypeParser
    {
    }
}